# RK3566 Handy V13 touchscreen addition

## Confirmed hardware mapping

- Controller protocol: FocalTech FT5x06-family register layout
- I2C address: `0x38`
- I2C1 SCL: GPIO0_B3 (`I2C1_SCL_TP`)
- I2C1 SDA: GPIO0_B4 (`I2C1_SDA_TP`)
- Interrupt: GPIO1_A0 (`TP_INT`), active low
- Reset: GPIO1_A1 (`TP_RST`), active high in the supplied driver
- Coordinates: 480 x 800

The TP bus is not crossed. The separately named sensor nets are the crossed
connection and are unrelated to this touchscreen configuration.

## Why the V13 DTB alone is insufficient

V13 has I2C and input support, but its embedded kernel config does not contain
the supplied `dx_touch` driver. The driver must be built against the exact
Rockchip 4.19.232 kernel source used by V13 and installed into the rootfs.

## Build as a module in the Linux SDK

From the kernel source tree, with the same `.config` and toolchain used for the
V13 kernel:

```sh
make ARCH=arm64 olddefconfig
make ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu- modules_prepare
make -C "$PWD" ARCH=arm64 CROSS_COMPILE=aarch64-linux-gnu- \
    M=/absolute/path/to/touchscreen_v14/dx_touch modules
```

Copy `dx_touch.ko` to the board, then:

```sh
sudo mkdir -p /lib/modules/$(uname -r)/extra
sudo cp dx_touch.ko /lib/modules/$(uname -r)/extra/
sudo depmod -a
echo dx_touch | sudo tee /etc/modules-load.d/dx_touch.conf
sudo modprobe dx_touch
```

## Verify

```sh
i2cdetect -y 1
dmesg | grep -Ei 'DX_TOUCH|touch|i2c'
cat /proc/bus/input/devices
ls -l /dev/input/event*
```

Before the module is installed, the prepared V14 boot image can still be used
to verify that address `0x38` appears on I2C1.
